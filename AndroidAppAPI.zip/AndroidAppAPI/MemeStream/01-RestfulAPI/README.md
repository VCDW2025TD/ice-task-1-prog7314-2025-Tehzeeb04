# MemeStream API

A RESTful API for the MemeStream app built with Node.js, Express, and MongoDB. This API handles meme data storage, retrieval, and social features like likes and comments.

## 🚀 Features

- **CRUD Operations**: Create, read, update, and delete memes
- **User-based Filtering**: Get memes by specific users
- **Search & Filtering**: Search memes by title, description, tags, and category
- **Social Features**: Like/unlike memes, view counts, comments
- **Pagination**: Efficient data loading with pagination support
- **Sorting**: Sort by recent, popular, oldest, or view count
- **Data Validation**: Comprehensive input validation and error handling
- **MongoDB Integration**: Optimized database queries with indexes

## 📋 API Endpoints

### Health Check
```
GET /api/health
```

### Memes

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/memes` | Create a new meme |
| `GET` | `/api/memes` | Get all memes (with filtering) |
| `GET` | `/api/memes/:id` | Get a specific meme by ID |
| `PUT` | `/api/memes/:id` | Update a meme (owner only) |
| `DELETE` | `/api/memes/:id` | Delete a meme (owner only) |
| `POST` | `/api/memes/:id/like` | Like/unlike a meme |
| `GET` | `/api/memes/special/popular` | Get popular memes |
| `GET` | `/api/memes/special/recent` | Get recent memes |

### Query Parameters for GET /api/memes

- `userId` - Filter by user ID
- `category` - Filter by category
- `tags` - Filter by tags (comma-separated)
- `search` - Search in title, description, and tags
- `limit` - Items per page (max 100, default 20)
- `page` - Page number (default 1)
- `sort` - Sort order: 'recent', 'popular', 'oldest', 'views'

## 📝 Data Models

### Meme Model

```javascript
{
  title: String (required, max 200 chars),
  description: String (max 1000 chars),
  imageUrl: String (required),
  imageType: String (enum: jpeg, png, gif, webp),
  userId: String (required),
  username: String (required, max 50 chars),
  category: String (default: 'general'),
  tags: [String] (max 30 chars each),
  likes: Number (default 0),
  views: Number (default 0),
  shares: Number (default 0),
  isPublic: Boolean (default true),
  isApproved: Boolean (default true),
  createdAt: Date,
  updatedAt: Date
}
```

## 🛠️ Setup Instructions

### Prerequisites

- Node.js (v16 or higher)
- MongoDB (local or MongoDB Atlas)
- npm or yarn package manager

### Installation

1. **Install Node.js dependencies:**
   ```bash
   npm install
   ```

2. **Set up environment variables:**
   Copy the configuration in `config.js` and create a `.env` file:
   ```
   PORT=3000
   NODE_ENV=development
   MONGODB_URI=mongodb://localhost:27017/memestream
   # For MongoDB Atlas:
   # MONGODB_URI=mongodb+srv://<username>:<password>@<cluster>.mongodb.net/memestream
   ```

3. **Start the server:**
   ```bash
   # Development mode (with nodemon)
   npm run dev
   
   # Production mode
   npm start
   ```

4. **Verify installation:**
   Visit `http://localhost:3000/api/health` to check if the API is running.

## 🌐 MongoDB Setup Options

### Option 1: Local MongoDB
1. Install MongoDB locally
2. Start MongoDB service
3. Use connection string: `mongodb://localhost:27017/memestream`

### Option 2: MongoDB Atlas (Recommended)
1. Create a free account at [MongoDB Atlas](https://www.mongodb.com/atlas)
2. Create a new cluster
3. Get your connection string
4. Update `MONGODB_URI` in your `.env` file

## 🧪 Testing the API

### Using curl:

**Create a meme:**
```bash
curl -X POST http://localhost:3000/api/memes \\
  -H "Content-Type: application/json" \\
  -d '{
    "title": "Funny Cat Meme",
    "description": "A hilarious cat doing something silly",
    "imageUrl": "https://example.com/cat-meme.jpg",
    "userId": "user123",
    "username": "memeLover",
    "category": "animals",
    "tags": ["cat", "funny", "pets"]
  }'
```

**Get all memes:**
```bash
curl http://localhost:3000/api/memes
```

**Get memes by user:**
```bash
curl http://localhost:3000/api/memes?userId=user123
```

**Search memes:**
```bash
curl "http://localhost:3000/api/memes?search=funny&category=animals"
```

### Using Postman:

1. Import the API endpoints into Postman
2. Set base URL to `http://localhost:3000`
3. Test each endpoint with sample data

## 🚀 Deployment

### Railway (Recommended)
1. Create account at [Railway](https://railway.app)
2. Connect your GitHub repository
3. Add environment variables in Railway dashboard
4. Deploy automatically from main branch

### Render
1. Create account at [Render](https://render.com)
2. Create new Web Service
3. Connect your repository
4. Set environment variables
5. Deploy

### Firebase Cloud Functions
1. Install Firebase CLI: `npm install -g firebase-tools`
2. Initialize Firebase project: `firebase init`
3. Deploy functions: `firebase deploy --only functions`

## 📊 Database Indexes

The following indexes are automatically created for optimal performance:

- `{ userId: 1, createdAt: -1 }` - User's memes by date
- `{ category: 1, createdAt: -1 }` - Category filtering
- `{ tags: 1 }` - Tag searching
- `{ isPublic: 1, isApproved: 1, createdAt: -1 }` - Public memes

## 🔧 Error Handling

The API includes comprehensive error handling:

- **400 Bad Request**: Invalid input data
- **401 Unauthorized**: Authentication required
- **403 Forbidden**: Insufficient permissions
- **404 Not Found**: Resource not found
- **500 Internal Server Error**: Server errors

All errors return JSON with:
```javascript
{
  error: "Error message",
  details: "Detailed error information",
  timestamp: "2023-XX-XXTXX:XX:XX.XXXZ"
}
```

## 📈 Performance Features

- **Pagination**: Efficient data loading
- **Field Selection**: Exclude sensitive data from responses
- **Database Indexes**: Optimized query performance
- **Request Logging**: Monitor API usage
- **Input Validation**: Prevent invalid data

## 🔒 Security Considerations

- Input validation and sanitization
- CORS configuration
- Rate limiting (implement with express-rate-limit)
- Authentication (implement JWT for production)
- Data encryption for sensitive fields

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make changes with proper testing
4. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details.

---

**Happy Meme Streaming! 🎉**
