// Test Script for MemeStream API
// Run this script to test all API endpoints after setting up the server

const axios = require('axios');

// Configuration
const BASE_URL = 'http://localhost:3000';
const API_URL = `${BASE_URL}/api`;

// Test data
const testMeme = {
  title: "Epic Developer Meme",
  description: "When your code works on the first try",
  imageUrl: "https://via.placeholder.com/500x400/009578/fff.png?text=Epic+Dev+Meme",
  userId: "dev123",
  username: "CodeMaster",
  category: "programming",
  tags: ["coding", "funny", "developer", "programming"]
};

const testMeme2 = {
  title: "Cat Coding Meme",
  description: "My face when debugging at 3 AM",
  imageUrl: "https://via.placeholder.com/500x400/FF6B6B/fff.png?text=Cat+Coding",
  userId: "dev456",
  username: "NightOwlDev",
  category: "animals",
  tags: ["cat", "coding", "debugging", "late-night"]
};

// Helper function for making requests
async function makeRequest(method, url, data = null) {
  try {
    const config = {
      method,
      url: `${API_URL}${url}`,
      headers: {
        'Content-Type': 'application/json'
      }
    };
    
    if (data) {
      config.data = data;
    }
    
    const response = await axios(config);
    return { success: true, data: response.data, status: response.status };
  } catch (error) {
    return {
      success: false,
      error: error.response?.data || error.message,
      status: error.response?.status || 500
    };
  }
}

// Test functions
async function testHealthCheck() {
  console.log('\\n🏥 Testing Health Check...');
  const result = await makeRequest('GET', '/health');
  
  if (result.success) {
    console.log('✅ Health check passed');
    console.log('   Status:', result.data.status);
    console.log('   Message:', result.data.message);
  } else {
    console.log('❌ Health check failed:', result.error);
  }
  
  return result.success;
}

async function testCreateMeme() {
  console.log('\\n📝 Testing Create Meme...');
  const result = await makeRequest('POST', '/memes', testMeme);
  
  if (result.success) {
    console.log('✅ Meme created successfully');
    console.log('   Meme ID:', result.data.meme._id);
    console.log('   Title:', result.data.meme.title);
    return result.data.meme;
  } else {
    console.log('❌ Failed to create meme:', result.error);
    return null;
  }
}

async function testCreateSecondMeme() {
  console.log('\\n📝 Testing Create Second Meme...');
  const result = await makeRequest('POST', '/memes', testMeme2);
  
  if (result.success) {
    console.log('✅ Second meme created successfully');
    console.log('   Meme ID:', result.data.meme._id);
    console.log('   Title:', result.data.meme.title);
    return result.data.meme;
  } else {
    console.log('❌ Failed to create second meme:', result.error);
    return null;
  }
}

async function testGetAllMemes() {
  console.log('\\n📋 Testing Get All Memes...');
  const result = await makeRequest('GET', '/memes');
  
  if (result.success) {
    console.log('✅ Retrieved memes successfully');
    console.log('   Total memes:', result.data.memes.length);
    console.log('   Pagination info:', result.data.pagination);
  } else {
    console.log('❌ Failed to get memes:', result.error);
  }
  
  return result.success;
}

async function testGetMemeById(memeId) {
  console.log('\\n🔍 Testing Get Meme by ID...');
  const result = await makeRequest('GET', `/memes/${memeId}`);
  
  if (result.success) {
    console.log('✅ Retrieved meme by ID successfully');
    console.log('   Title:', result.data.meme.title);
    console.log('   Views:', result.data.meme.views);
  } else {
    console.log('❌ Failed to get meme by ID:', result.error);
  }
  
  return result.success;
}

async function testGetMemesByUser() {
  console.log('\\n👤 Testing Get Memes by User...');
  const result = await makeRequest('GET', `/memes?userId=${testMeme.userId}`);
  
  if (result.success) {
    console.log('✅ Retrieved memes by user successfully');
    console.log('   User memes count:', result.data.memes.length);
  } else {
    console.log('❌ Failed to get memes by user:', result.error);
  }
  
  return result.success;
}

async function testSearchMemes() {
  console.log('\\n🔎 Testing Search Memes...');
  const result = await makeRequest('GET', '/memes?search=coding&category=programming');
  
  if (result.success) {
    console.log('✅ Search completed successfully');
    console.log('   Search results:', result.data.memes.length);
  } else {
    console.log('❌ Failed to search memes:', result.error);
  }
  
  return result.success;
}

async function testLikeMeme(memeId) {
  console.log('\\n❤️ Testing Like Meme...');
  const result = await makeRequest('POST', `/memes/${memeId}/like`, {
    userId: 'testuser123'
  });
  
  if (result.success) {
    console.log('✅ Meme liked successfully');
    console.log('   Liked:', result.data.liked);
    console.log('   Total likes:', result.data.likes);
  } else {
    console.log('❌ Failed to like meme:', result.error);
  }
  
  return result.success;
}

async function testUpdateMeme(memeId) {
  console.log('\\n✏️ Testing Update Meme...');
  const updateData = {
    userId: testMeme.userId, // Must be the owner
    title: "Updated Epic Developer Meme",
    description: "When your code works on the first try - Updated!",
    tags: ["coding", "funny", "developer", "programming", "updated"]
  };
  
  const result = await makeRequest('PUT', `/memes/${memeId}`, updateData);
  
  if (result.success) {
    console.log('✅ Meme updated successfully');
    console.log('   New title:', result.data.meme.title);
  } else {
    console.log('❌ Failed to update meme:', result.error);
  }
  
  return result.success;
}

async function testGetPopularMemes() {
  console.log('\\n🔥 Testing Get Popular Memes...');
  const result = await makeRequest('GET', '/memes/special/popular?limit=5');
  
  if (result.success) {
    console.log('✅ Retrieved popular memes successfully');
    console.log('   Popular memes count:', result.data.count);
  } else {
    console.log('❌ Failed to get popular memes:', result.error);
  }
  
  return result.success;
}

async function testGetRecentMemes() {
  console.log('\\n⏰ Testing Get Recent Memes...');
  const result = await makeRequest('GET', '/memes/special/recent?limit=5');
  
  if (result.success) {
    console.log('✅ Retrieved recent memes successfully');
    console.log('   Recent memes count:', result.data.count);
  } else {
    console.log('❌ Failed to get recent memes:', result.error);
  }
  
  return result.success;
}

async function testValidation() {
  console.log('\\n🛡️ Testing Input Validation...');
  const invalidMeme = {
    // Missing required fields
    description: "This should fail validation"
  };
  
  const result = await makeRequest('POST', '/memes', invalidMeme);
  
  if (!result.success && result.status === 400) {
    console.log('✅ Validation working correctly');
    console.log('   Error:', result.error.error);
  } else {
    console.log('❌ Validation not working properly');
  }
  
  return !result.success;
}

// Main test runner
async function runAllTests() {
  console.log('🧪 Starting MemeStream API Tests');
  console.log('=====================================');
  
  let passedTests = 0;
  let totalTests = 0;
  let createdMeme = null;
  let createdMeme2 = null;
  
  // Test 1: Health Check
  totalTests++;
  if (await testHealthCheck()) passedTests++;
  
  // Test 2: Validation
  totalTests++;
  if (await testValidation()) passedTests++;
  
  // Test 3: Create Meme
  totalTests++;
  createdMeme = await testCreateMeme();
  if (createdMeme) passedTests++;
  
  // Test 4: Create Second Meme
  totalTests++;
  createdMeme2 = await testCreateSecondMeme();
  if (createdMeme2) passedTests++;
  
  // Test 5: Get All Memes
  totalTests++;
  if (await testGetAllMemes()) passedTests++;
  
  // Test 6: Get Meme by ID
  if (createdMeme) {
    totalTests++;
    if (await testGetMemeById(createdMeme._id)) passedTests++;
  }
  
  // Test 7: Get Memes by User
  totalTests++;
  if (await testGetMemesByUser()) passedTests++;
  
  // Test 8: Search Memes
  totalTests++;
  if (await testSearchMemes()) passedTests++;
  
  // Test 9: Like Meme
  if (createdMeme) {
    totalTests++;
    if (await testLikeMeme(createdMeme._id)) passedTests++;
  }
  
  // Test 10: Update Meme
  if (createdMeme) {
    totalTests++;
    if (await testUpdateMeme(createdMeme._id)) passedTests++;
  }
  
  // Test 11: Get Popular Memes
  totalTests++;
  if (await testGetPopularMemes()) passedTests++;
  
  // Test 12: Get Recent Memes
  totalTests++;
  if (await testGetRecentMemes()) passedTests++;
  
  // Results
  console.log('\\n📊 Test Results');
  console.log('=================');
  console.log(`✅ Passed: ${passedTests}/${totalTests}`);
  console.log(`❌ Failed: ${totalTests - passedTests}/${totalTests}`);
  console.log(`📈 Success Rate: ${((passedTests / totalTests) * 100).toFixed(1)}%`);
  
  if (passedTests === totalTests) {
    console.log('\\n🎉 All tests passed! Your API is working correctly.');
  } else {
    console.log('\\n⚠️  Some tests failed. Check the error messages above.');
  }
  
  console.log('\\n💡 Next Steps:');
  console.log('   1. Set up MongoDB Atlas for production');
  console.log('   2. Deploy to Railway, Render, or Firebase');
  console.log('   3. Test with Postman for detailed API exploration');
  console.log('   4. Integrate with your Android app');
}

// Check if axios is available
async function checkDependencies() {
  try {
    require('axios');
    return true;
  } catch (error) {
    console.log('❌ axios is required for testing. Install it with:');
    console.log('   npm install axios');
    return false;
  }
}

// Run tests
async function main() {
  if (await checkDependencies()) {
    await runAllTests();
  }
}

// Export for module usage or run directly
if (require.main === module) {
  main().catch(console.error);
}

module.exports = {
  runAllTests,
  testHealthCheck,
  testCreateMeme,
  testGetAllMemes,
  makeRequest
};
