// Meme Routes - RESTful API endpoints for meme operations
const express = require('express');
const router = express.Router();
const Meme = require('../models/Meme');

// Utility function for error handling
const handleError = (res, error, message = 'An error occurred') => {
  console.error(error);
  res.status(500).json({
    error: message,
    details: error.message,
    timestamp: new Date().toISOString()
  });
};

// Validation middleware
const validateMemeData = (req, res, next) => {
  const { title, imageUrl, userId, username } = req.body;
  
  if (!title || title.trim().length === 0) {
    return res.status(400).json({
      error: 'Title is required',
      timestamp: new Date().toISOString()
    });
  }
  
  if (!imageUrl || imageUrl.trim().length === 0) {
    return res.status(400).json({
      error: 'Image URL is required',
      timestamp: new Date().toISOString()
    });
  }
  
  if (!userId || userId.trim().length === 0) {
    return res.status(400).json({
      error: 'User ID is required',
      timestamp: new Date().toISOString()
    });
  }
  
  if (!username || username.trim().length === 0) {
    return res.status(400).json({
      error: 'Username is required',
      timestamp: new Date().toISOString()
    });
  }
  
  next();
};

// POST /api/memes - Create a new meme
router.post('/', validateMemeData, async (req, res) => {
  try {
    const memeData = {
      title: req.body.title,
      description: req.body.description || '',
      imageUrl: req.body.imageUrl,
      imageType: req.body.imageType || 'image/jpeg',
      userId: req.body.userId,
      username: req.body.username,
      category: req.body.category || 'general',
      tags: req.body.tags || [],
      isPublic: req.body.isPublic !== undefined ? req.body.isPublic : true
    };
    
    const newMeme = new Meme(memeData);
    const savedMeme = await newMeme.save();
    
    res.status(201).json({
      message: 'Meme created successfully',
      meme: savedMeme,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    handleError(res, error, 'Failed to create meme');
  }
});

// GET /api/memes - Get all memes with optional filtering
router.get('/', async (req, res) => {
  try {
    const {
      userId,
      category,
      tags,
      limit = 20,
      page = 1,
      sort = 'recent',
      search
    } = req.query;
    
    // Build query object
    let query = { isPublic: true, isApproved: true };
    
    if (userId) {
      query.userId = userId;
    }
    
    if (category) {
      query.category = category;
    }
    
    if (tags) {
      const tagArray = Array.isArray(tags) ? tags : tags.split(',');
      query.tags = { $in: tagArray };
    }
    
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { tags: { $regex: search, $options: 'i' } }
      ];
    }
    
    // Build sort object
    let sortObj = {};
    switch (sort) {
      case 'popular':
        sortObj = { likes: -1, views: -1, createdAt: -1 };
        break;
      case 'oldest':
        sortObj = { createdAt: 1 };
        break;
      case 'views':
        sortObj = { views: -1, createdAt: -1 };
        break;
      case 'recent':
      default:
        sortObj = { createdAt: -1 };
        break;
    }
    
    // Calculate pagination
    const limitNum = Math.min(parseInt(limit), 100); // Max 100 items per page
    const skip = (parseInt(page) - 1) * limitNum;
    
    // Execute query
    const memes = await Meme.find(query)
      .sort(sortObj)
      .skip(skip)
      .limit(limitNum)
      .select('-likedBy -reportedBy'); // Exclude sensitive arrays for performance
    
    // Get total count for pagination
    const totalCount = await Meme.countDocuments(query);
    const totalPages = Math.ceil(totalCount / limitNum);
    
    res.json({
      memes,
      pagination: {
        currentPage: parseInt(page),
        totalPages,
        totalItems: totalCount,
        itemsPerPage: limitNum,
        hasNextPage: parseInt(page) < totalPages,
        hasPreviousPage: parseInt(page) > 1
      },
      filters: {
        userId,
        category,
        tags,
        search,
        sort
      },
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    handleError(res, error, 'Failed to fetch memes');
  }
});

// GET /api/memes/:id - Get a specific meme by ID
router.get('/:id', async (req, res) => {
  try {
    const meme = await Meme.findById(req.params.id);
    
    if (!meme) {
      return res.status(404).json({
        error: 'Meme not found',
        timestamp: new Date().toISOString()
      });
    }
    
    // Increment view count
    await meme.incrementViews();
    
    res.json({
      meme,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    if (error.name === 'CastError') {
      return res.status(400).json({
        error: 'Invalid meme ID format',
        timestamp: new Date().toISOString()
      });
    }
    handleError(res, error, 'Failed to fetch meme');
  }
});

// PUT /api/memes/:id - Update a meme
router.put('/:id', async (req, res) => {
  try {
    const { userId } = req.body;
    const meme = await Meme.findById(req.params.id);
    
    if (!meme) {
      return res.status(404).json({
        error: 'Meme not found',
        timestamp: new Date().toISOString()
      });
    }
    
    // Check if user owns this meme
    if (meme.userId !== userId) {
      return res.status(403).json({
        error: 'You can only update your own memes',
        timestamp: new Date().toISOString()
      });
    }
    
    // Update fields
    const updateFields = ['title', 'description', 'category', 'tags', 'isPublic'];
    updateFields.forEach(field => {
      if (req.body[field] !== undefined) {
        meme[field] = req.body[field];
      }
    });
    
    const updatedMeme = await meme.save();
    
    res.json({
      message: 'Meme updated successfully',
      meme: updatedMeme,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    if (error.name === 'CastError') {
      return res.status(400).json({
        error: 'Invalid meme ID format',
        timestamp: new Date().toISOString()
      });
    }
    handleError(res, error, 'Failed to update meme');
  }
});

// DELETE /api/memes/:id - Delete a meme
router.delete('/:id', async (req, res) => {
  try {
    const { userId } = req.body;
    const meme = await Meme.findById(req.params.id);
    
    if (!meme) {
      return res.status(404).json({
        error: 'Meme not found',
        timestamp: new Date().toISOString()
      });
    }
    
    // Check if user owns this meme
    if (meme.userId !== userId) {
      return res.status(403).json({
        error: 'You can only delete your own memes',
        timestamp: new Date().toISOString()
      });
    }
    
    await Meme.findByIdAndDelete(req.params.id);
    
    res.json({
      message: 'Meme deleted successfully',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    if (error.name === 'CastError') {
      return res.status(400).json({
        error: 'Invalid meme ID format',
        timestamp: new Date().toISOString()
      });
    }
    handleError(res, error, 'Failed to delete meme');
  }
});

// POST /api/memes/:id/like - Like/Unlike a meme
router.post('/:id/like', async (req, res) => {
  try {
    const { userId } = req.body;
    
    if (!userId) {
      return res.status(400).json({
        error: 'User ID is required',
        timestamp: new Date().toISOString()
      });
    }
    
    const meme = await Meme.findById(req.params.id);
    
    if (!meme) {
      return res.status(404).json({
        error: 'Meme not found',
        timestamp: new Date().toISOString()
      });
    }
    
    const existingLike = meme.likedBy.find(like => like.userId === userId);
    
    if (existingLike) {
      // Unlike the meme
      await meme.removeLike(userId);
      res.json({
        message: 'Meme unliked successfully',
        liked: false,
        likes: meme.likes,
        timestamp: new Date().toISOString()
      });
    } else {
      // Like the meme
      await meme.addLike(userId);
      res.json({
        message: 'Meme liked successfully',
        liked: true,
        likes: meme.likes,
        timestamp: new Date().toISOString()
      });
    }
  } catch (error) {
    if (error.name === 'CastError') {
      return res.status(400).json({
        error: 'Invalid meme ID format',
        timestamp: new Date().toISOString()
      });
    }
    handleError(res, error, 'Failed to process like');
  }
});

// GET /api/memes/popular - Get popular memes
router.get('/special/popular', async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit) || 10, 50);
    const memes = await Meme.getPopular(limit);
    
    res.json({
      memes,
      count: memes.length,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    handleError(res, error, 'Failed to fetch popular memes');
  }
});

// GET /api/memes/recent - Get recent memes
router.get('/special/recent', async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit) || 10, 50);
    const memes = await Meme.getRecent(limit);
    
    res.json({
      memes,
      count: memes.length,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    handleError(res, error, 'Failed to fetch recent memes');
  }
});

module.exports = router;
